import { MessageCircle, Phone, Users, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import VideoCallModal from "@/components/VideoCallModal";
import MessageInput from "@/components/MessageInput";
import { ContactsModal } from "@/components/ContactsModal";
import ChatMessage from "@/components/ChatMessage";
import { useState } from "react";
import { MobileNavigation } from "@/components/MobileNavigation";
import { DesktopSidebar } from "@/components/DesktopSidebar";

const Index = () => {
  const [messages, setMessages] = useState([
    { id: 1, text: "Hey BossM! Ready for band practice? 🎸", sender: "Jam", time: "9:41 AM", type: "text" as const },
    { id: 2, text: "Hi! Yes, let's meet at the usual place!", sender: "You", time: "9:42 AM", type: "text" as const },
    { id: 3, image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b", sender: "Buboy", time: "9:43 AM", type: "image" as const },
  ]);
  const [newMessage, setNewMessage] = useState("");
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showContactsModal, setShowContactsModal] = useState(false);
  const { toast } = useToast();

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    setMessages([
      ...messages,
      {
        id: messages.length + 1,
        text: newMessage,
        sender: "You",
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: "text"
      }
    ]);
    setNewMessage("");
  };

  const handleVoiceCall = () => {
    toast({
      title: "Voice Call",
      description: "Starting voice call...",
    });
  };

  const handleProfileClick = () => {
    toast({
      title: "Profile",
      description: "Profile settings will be available soon!",
    });
  };

  return (
    <div className="flex h-screen bg-background">
      <MobileNavigation 
        handleProfileClick={handleProfileClick}
        setShowContactsModal={setShowContactsModal}
      />
      <DesktopSidebar />

      <div className="flex-1 flex flex-col h-full">
        <div className="hidden md:flex items-center justify-between px-6 py-4 border-b bg-card">
          <div className="flex items-center space-x-4">
            <div>
              <h2 className="text-sm font-medium">Jam</h2>
              <p className="text-xs text-muted-foreground">Online</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" onClick={handleVoiceCall} className="hover:bg-accent">
              <Phone className="h-5 w-5 text-muted-foreground" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setShowVideoModal(true)} className="hover:bg-accent">
              <Video className="h-5 w-5 text-muted-foreground" />
            </Button>
          </div>
        </div>

        <ScrollArea className="flex-1 p-4 bg-background mt-14 md:mt-0">
          <div className="space-y-4 pb-16 md:pb-0">
            {messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
          </div>
        </ScrollArea>

        <MessageInput 
          newMessage={newMessage}
          onMessageChange={setNewMessage}
          onSendMessage={handleSendMessage}
          roomUrl="https://your-daily-co-room-url"
        />
      </div>

      <ContactsModal open={showContactsModal} onClose={() => setShowContactsModal(false)} />
    </div>
  );
};

export default Index;
