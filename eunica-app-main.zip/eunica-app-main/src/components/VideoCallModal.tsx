import { useEffect, useRef } from "react";
import DailyIframe from "@daily-co/daily-js";
import { Dialog, DialogContent } from "./ui/dialog";
import { Button } from "./ui/button";
import { Phone } from "lucide-react";

interface VideoCallModalProps {
  open: boolean;
  onClose: () => void;
  roomUrl: string;
}

const VideoCallModal = ({ open, onClose, roomUrl }: VideoCallModalProps) => {
  const videoRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open && videoRef.current) {
      const callFrame = DailyIframe.createFrame(videoRef.current, {
        showLeaveButton: true,
        iframeStyle: {
          width: "100%",
          height: "100%",
          border: "0",
          borderRadius: "12px",
        },
      });

      callFrame.join({ url: roomUrl });

      return () => {
        callFrame.destroy();
      };
    }
  }, [open, roomUrl]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px]">
        <div className="h-[600px] relative">
          <div ref={videoRef} className="w-full h-full" />
          <Button
            onClick={onClose}
            size="icon"
            variant="destructive"
            className="absolute bottom-4 left-1/2 -translate-x-1/2"
          >
            <Phone className="h-5 w-5 rotate-135" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VideoCallModal;
