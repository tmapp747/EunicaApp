import { cn } from "@/lib/utils";
import { Avatar } from "./ui/avatar";

interface Message {
  id: number;
  text?: string;
  image?: string;
  sender: string;
  time: string;
  type: "text" | "image";
}

interface ChatMessageProps {
  message: Message;
}

const getMessageColor = (sender: string) => {
  if (sender === "You") return "bg-blue-500 text-white";
  
  // For group chats, assign different colors based on sender
  const colors = {
    "Sarah": "bg-green-500 text-white",
    "John": "bg-purple-500 text-white",
    "Emma": "bg-pink-500 text-white",
    "default": "bg-gray-500 text-white"
  };
  
  return colors[sender as keyof typeof colors] || colors.default;
};

const ChatMessage = ({ message }: ChatMessageProps) => {
  const isOwnMessage = message.sender === "You";

  return (
    <div
      className={cn(
        "flex items-start space-x-2 message-appear",
        isOwnMessage && "flex-row-reverse space-x-reverse"
      )}
    >
      <Avatar className="h-8 w-8 mt-1">
        <img
          src={isOwnMessage 
            ? "https://images.unsplash.com/photo-1519389950473-47ba0277781c"
            : "https://images.unsplash.com/photo-1649972904349-6e44c42644a7"
          }
          alt={message.sender}
        />
      </Avatar>
      <div className={cn("flex flex-col", isOwnMessage && "items-end")}>
        <div className="flex items-center space-x-2">
          <span className="text-sm font-medium">{message.sender}</span>
          <span className="text-xs text-muted-foreground">{message.time}</span>
        </div>
        {message.type === "text" ? (
          <div
            className={cn(
              "mt-1 rounded-lg px-4 py-2 max-w-md",
              getMessageColor(message.sender)
            )}
          >
            <p className="text-sm">{message.text}</p>
          </div>
        ) : (
          <div className="mt-1 rounded-lg overflow-hidden max-w-md">
            <img
              src={message.image}
              alt="Shared image"
              className="w-full h-auto"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;