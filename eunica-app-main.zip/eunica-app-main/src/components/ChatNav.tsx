import {
  MessageCircle,
  Phone,
  Users,
  Clock,
  User,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const NavItem = ({ icon, label, active, onClick }: NavItem) => (
  <button
    onClick={onClick}
    className={cn(
      "flex items-center space-x-2 w-full p-2 rounded-lg transition-colors",
      active 
        ? "bg-primary text-primary-foreground" 
        : "hover:bg-accent hover:text-accent-foreground"
    )}
  >
    {icon}
    <span>{label}</span>
  </button>
);

const ChatNav = () => {
  return (
    <div className="space-y-2 p-2">
      <NavItem
        icon={<User className="h-5 w-5" />}
        label="Profile"
        active
        onClick={() => {}}
      />
      <NavItem
        icon={<MessageCircle className="h-5 w-5" />}
        label="Chat History"
        onClick={() => {}}
      />
      <NavItem
        icon={<Clock className="h-5 w-5" />}
        label="Call History"
        onClick={() => {}}
      />
      <NavItem
        icon={<Users className="h-5 w-5" />}
        label="Contacts"
        onClick={() => {}}
      />
      <NavItem
        icon={<Settings className="h-5 w-5" />}
        label="Settings"
        onClick={() => {}}
      />
    </div>
  );
};

export default ChatNav;