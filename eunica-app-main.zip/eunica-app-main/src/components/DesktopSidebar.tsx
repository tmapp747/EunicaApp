import { Music, Home, AppWindow } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import ChatNav from "@/components/ChatNav";
import { Avatar } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";

export const DesktopSidebar = () => {
  const { toast } = useToast();

  const handleEunicaAIClick = () => {
    toast({
      title: "Coming Soon!",
      description: "Eunica AI - Your band's intelligent assistant will be available soon. Features will include: chord progression suggestions, practice scheduling, lyrics analysis, and band equipment management.",
    });
  };

  return (
    <div className="hidden md:flex w-64 flex-col bg-card border-r border-border">
      <div className="p-4 flex items-center space-x-2 border-b border-border sticky top-0 z-50 bg-card">
        <Music className="h-6 w-6 text-primary" />
        <h1 className="text-xl font-bold text-primary flex-1">Eunica Band Messenger</h1>
        <ThemeToggle />
      </div>
      <ChatNav />
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-2">
          <h2 className="text-sm font-semibold text-muted-foreground">Band Members - 5</h2>
          <div className="mt-2 space-y-2">
            {["BossM", "Jam", "Buboy", "Ruel", "Aira"].map((member) => (
              <div key={member} className="flex items-center space-x-2">
                <div className="relative">
                  <Avatar className="h-8 w-8">
                    <span className="text-xs">{member[0]}</span>
                  </Avatar>
                  <div className="absolute bottom-0 right-0 h-2 w-2 rounded-full bg-green-500 ring-2 ring-white" />
                </div>
                <span className="text-sm font-medium">{member}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-border sticky bottom-0 z-50 bg-card">
        <div className="p-2 flex items-center space-x-2">
          <button className="p-2 hover:bg-accent rounded-md" onClick={() => toast({ title: "Home", description: "Home section coming soon!" })}>
            <Home className="h-5 w-5 text-muted-foreground" />
          </button>
          <button className="p-2 hover:bg-accent rounded-md" onClick={handleEunicaAIClick}>
            <AppWindow className="h-5 w-5 text-muted-foreground" />
          </button>
        </div>
        <div className="p-2 bg-secondary">
          <div className="flex items-center justify-center space-x-2">
            <Music className="h-4 w-4 text-primary" />
            <p className="text-sm font-medium text-primary">
              Developed by Boss Marc
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};