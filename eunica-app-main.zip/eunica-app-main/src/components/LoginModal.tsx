import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "./ui/dialog";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

const staticUsers = [
  { username: "BossM", password: "BossM143" },
  { username: "Jam", password: "Jam143" },
  { username: "Ruel", password: "Ruel143" },
  { username: "Buboy", password: "Buboy143" },
  { username: "Aira", password: "Aira143" },
];

const LoginModal = ({ open, onClose, onLogin }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    const user = staticUsers.find(
      (user) => user.username === username && user.password === password
    );
    if (user) {
      onLogin(user);
      onClose();
    } else {
      setError("Invalid username or password");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Login</DialogTitle>
          <DialogDescription>
            Please enter your username and password to login.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleLogin}>
          <div className="space-y-4">
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              required
            />
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              required
            />
            {error && <p className="text-red-500 text-sm">{error}</p>}
          </div>
          <DialogFooter>
            <Button type="submit">Login</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default LoginModal;
