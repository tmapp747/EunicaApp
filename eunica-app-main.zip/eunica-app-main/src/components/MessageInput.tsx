import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Paperclip, ImageIcon, Send, Mic, Video } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { FileAttachmentModal } from "./FileAttachmentModal";
import { AudioRecorder } from "./AudioRecorder";
import VideoCallModal from "./VideoCallModal";

interface MessageInputProps {
  newMessage: string;
  onMessageChange: (value: string) => void;
  onSendMessage: (e: React.FormEvent) => void;
}

const MessageInput = ({ newMessage, onMessageChange, onSendMessage }: MessageInputProps) => {
  const { toast } = useToast();
  const [showFileModal, setShowFileModal] = useState(false);
  const [showAudioModal, setShowAudioModal] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);
  const [showVideoModal, setShowVideoModal] = useState(false);

  const handleImageUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        toast({
          title: "Image Upload",
          description: "Image uploaded successfully!",
        });
      }
    };
    input.click();
  };

  return (
    <>
      <form onSubmit={onSendMessage} className="p-4 bg-card border-t border-border sticky bottom-16 md:bottom-0">
        <div className="flex items-center space-x-2">
          <Button type="button" variant="ghost" size="icon" onClick={() => setShowFileModal(true)}>
            <Paperclip className="h-5 w-5 text-muted-foreground" />
          </Button>
          <Button type="button" variant="ghost" size="icon" onClick={() => setShowAudioModal(true)}>
            <Mic className="h-5 w-5 text-muted-foreground" />
          </Button>
          <Button type="button" variant="ghost" size="icon" onClick={handleImageUpload}>
            <ImageIcon className="h-5 w-5 text-muted-foreground" />
          </Button>
          <Button type="button" variant="ghost" size="icon" onClick={() => setShowVideoModal(true)}>
            <Video className="h-5 w-5 text-muted-foreground" />
          </Button>
          <Input
            value={newMessage}
            onChange={(e) => onMessageChange(e.target.value)}
            placeholder="Type a message..."
            className="flex-1"
          />
          <Button type="submit" size="icon" className="bg-primary hover:bg-primary/90">
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </form>

      <FileAttachmentModal
        open={showFileModal}
        onClose={() => setShowFileModal(false)}
      />
      <AudioRecorder
        open={showAudioModal}
        onClose={() => setShowAudioModal(false)}
      />
      <VideoCallModal
        open={showVideoModal}
        onClose={() => setShowVideoModal(false)}
      />
    </>
  );
};

export default MessageInput;
