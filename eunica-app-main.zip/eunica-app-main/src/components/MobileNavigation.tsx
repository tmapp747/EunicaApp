import { MessageCircle, Phone, Users, Clock, User, Settings, Menu, Music } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { ThemeToggle } from "@/components/theme-toggle";

interface MobileNavigationProps {
  handleProfileClick: () => void;
  setShowContactsModal: (show: boolean) => void;
}

export const MobileNavigation = ({ handleProfileClick, setShowContactsModal }: MobileNavigationProps) => {
  return (
    <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-card border-b border-border z-[100] flex items-center justify-between px-4">
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon">
            <Menu className="h-6 w-6 text-muted-foreground" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[300px] sm:w-[400px]">
          <SheetHeader>
            <SheetTitle className="flex items-center space-x-2">
              <Music className="h-6 w-6 text-primary" />
              <span>Eunica Band Messenger</span>
            </SheetTitle>
          </SheetHeader>
          <div className="py-6">
            <div className="space-y-4">
              <Button variant="ghost" className="w-full justify-start" onClick={handleProfileClick}>
                <User className="mr-2 h-5 w-5" />
                Profile
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <MessageCircle className="mr-2 h-5 w-5" />
                Chat History
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Clock className="mr-2 h-5 w-5" />
                Call History
              </Button>
              <Button variant="ghost" className="w-full justify-start" onClick={() => setShowContactsModal(true)}>
                <Users className="mr-2 h-5 w-5" />
                Contacts
              </Button>
              <Separator />
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Button variant="ghost" className="w-full justify-start">
                    <Settings className="mr-2 h-5 w-5" />
                    Settings
                  </Button>
                  <ThemeToggle />
                </div>
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>
      <div className="flex items-center space-x-2">
        <Music className="h-6 w-6 text-primary" />
        <h1 className="text-lg font-bold">Eunica Band Messenger</h1>
      </div>
      <Button variant="ghost" size="icon" onClick={handleProfileClick}>
        <User className="h-6 w-6 text-muted-foreground" />
      </Button>
    </div>
  );
};