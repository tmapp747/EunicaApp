import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { MessageCircle, Phone, Video } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Contact {
  id: number;
  name: string;
  avatar: string;
  online: boolean;
}

const contacts: Contact[] = [
  {
    id: 1,
    name: "Jam",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
    online: true
  },
  {
    id: 2,
    name: "Ruel",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde",
    online: true
  },
  {
    id: 3,
    name: "Buboy",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde",
    online: false
  },
  {
    id: 4,
    name: "Aira",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
    online: true
  }
];

export const ContactsModal = ({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) => {
  const { toast } = useToast();

  const handleInteraction = (contact: Contact, type: 'chat' | 'voice' | 'video') => {
    const actions = {
      chat: 'Starting chat with',
      voice: 'Starting voice call with',
      video: 'Starting video call with'
    };
    
    toast({
      title: type.charAt(0).toUpperCase() + type.slice(1),
      description: `${actions[type]} ${contact.name}`
    });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Contacts</DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[300px] pr-4">
          <div className="space-y-4">
            {contacts.map((contact) => (
              <div key={contact.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-accent">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="h-10 w-10">
                      <img src={contact.avatar} alt={contact.name} />
                    </Avatar>
                    <div className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background ${contact.online ? 'bg-green-500' : 'bg-gray-400'}`} />
                  </div>
                  <span className="font-medium">{contact.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => handleInteraction(contact, 'chat')}
                    disabled={!contact.online}
                  >
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => handleInteraction(contact, 'voice')}
                    disabled={!contact.online}
                  >
                    <Phone className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => handleInteraction(contact, 'video')}
                    disabled={!contact.online}
                  >
                    <Video className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};